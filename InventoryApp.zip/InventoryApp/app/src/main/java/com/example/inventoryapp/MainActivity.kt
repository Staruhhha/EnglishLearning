package com.example.inventoryapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.MenuItem
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.core.view.get
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.example.inventoryapp.data.UserInfo
import com.example.inventoryapp.models.Users
import com.google.android.material.navigation.NavigationView
import io.paperdb.Paper

class MainActivity : AppCompatActivity() {

    lateinit var toggle: ActionBarDrawerToggle
    lateinit var buttonExit : LinearLayout
    private val receiveFragment : ReceiveFragment = ReceiveFragment()
    private val inWorkFragment : InWorkFragment = InWorkFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Paper.init(this)
        val userInfo : Users? = UserInfo.getEmployeeInfo()

        val drawerLayout : DrawerLayout = findViewById(R.id.drawerLayout)
        val navView : NavigationView = findViewById(R.id.nav_view)

        buttonExit = findViewById(R.id.button_exit)

        replaceFragment(receiveFragment)
        setToolbarTitle("Полученные заявки")

        toggle = ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        val headerView = navView.getHeaderView(0)
        val name = headerView.findViewById<TextView>(R.id.employee_name)
        name.text = "${userInfo!!.employee.surname} ${userInfo!!.employee.name}"

        buttonExit.setOnClickListener {
            Paper.book("user").destroy()
            val intentExit = Intent(this, LaunchActivity::class.java)
            startActivity(intentExit)
            finish()
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        navView.setNavigationItemSelectedListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            when(it.itemId){
                R.id.receive_req -> {
                    replaceFragment(receiveFragment)
                    setToolbarTitle(it.title.toString())
                }
                R.id.in_work_req -> {
                    replaceFragment(inWorkFragment)
                    setToolbarTitle(it.title.toString())
                }
            }
            true
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if (toggle.onOptionsItemSelected(item)) return true

        return super.onOptionsItemSelected(item)
    }

    private fun replaceFragment(fragment: Fragment){
        if (fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, fragment)
            transaction.commit()
        }
    }

    private fun setToolbarTitle(title : String){
        supportActionBar?.title = title
    }

}