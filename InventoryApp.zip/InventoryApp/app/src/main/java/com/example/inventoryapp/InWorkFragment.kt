package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.inventoryapp.data.UserInfo
import com.example.inventoryapp.models.RequestTechnic
import com.example.inventoryapp.services.ApiRequests
import com.example.inventoryapp.services.ServiceBuilder
import io.paperdb.Paper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class InWorkFragment : Fragment() {

    private lateinit var listInWork : RecyclerView
    private lateinit var progressInWork : ProgressBar

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        var item = UserInfo.getEmployeeInfo()
        progressInWork.visibility = View.VISIBLE
        getData(item!!.employeeID)

    }

    private fun getData(id: Int) {
        val serviceBuilder = ServiceBuilder.buildServices(ApiRequests::class.java)
        val requestCall = serviceBuilder.getInWorkRequest(id)
        requestCall.enqueue(object : Callback<ArrayList<RequestTechnic>> {
            override fun onResponse(
                call: Call<ArrayList<RequestTechnic>>,
                response: Response<ArrayList<RequestTechnic>>
            ) {
                listInWork.layoutManager = LinearLayoutManager(context)
                listInWork.setHasFixedSize(true)
                listInWork.adapter = ReceivedAdapter(context!!, response.body()!!){
                    val intent = Intent(context, DetailInWorkActivity::class.java)
                    intent.putExtra("idReq", it.iDRequest)
                    startActivity(intent)
                }
                progressInWork.visibility = View.GONE
            }

            override fun onFailure(call: Call<ArrayList<RequestTechnic>>, t: Throwable) {
                Toast.makeText(context, "${t.message}", Toast.LENGTH_SHORT).show()
            }

        })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val inWork = inflater.inflate(R.layout.fragment_in_work, container, false)
        Paper.init(requireContext())
        listInWork = inWork.findViewById(R.id.in_work_list)
        progressInWork = inWork.findViewById(R.id.progress_in)
        return inWork
    }


}