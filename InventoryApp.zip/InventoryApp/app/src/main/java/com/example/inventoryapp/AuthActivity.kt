package com.example.inventoryapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.inventoryapp.data.UserInfo
import com.example.inventoryapp.models.Users
import com.example.inventoryapp.services.ApiRequests
import com.example.inventoryapp.services.ServiceBuilder
import io.paperdb.Paper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AuthActivity : AppCompatActivity() {

    private lateinit var editTextLogin : EditText
    private lateinit var editTextPassword: EditText
    private lateinit var loginButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)

        Paper.init(this)

        supportActionBar?.title = "Авторизация"

        editTextLogin = findViewById(R.id.text_login)
        editTextPassword = findViewById(R.id.text_password)
        loginButton = findViewById(R.id.button_login)

        loginButton.setOnClickListener {
            authUser(editTextLogin.text.toString(), editTextPassword.text.toString())
        }

    }

    private fun authUser(login: String?, password: String?) {
        val serviceBuilder = ServiceBuilder.buildServices(ApiRequests::class.java)
        val requestCall = serviceBuilder.authUserByLogin(login)
        requestCall.enqueue(object : Callback<Users>{
            override fun onResponse(call: Call<Users>, response: Response<Users>) {
                if (response.isSuccessful){
                    if (response.body()!!.password == password){
                        UserInfo.addUserInfo(response.body()!!)
                        val intent = Intent(this@AuthActivity, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    }else{
                        Toast.makeText(this@AuthActivity, "Неверный пароль", Toast.LENGTH_SHORT).show()
                    }
                }else{
                    Toast.makeText(this@AuthActivity, "Пользователя с таким логином не существует", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Users>, t: Throwable) {
                Toast.makeText(this@AuthActivity, "${t.message}", Toast.LENGTH_SHORT).show()
            }

        })
    }
}