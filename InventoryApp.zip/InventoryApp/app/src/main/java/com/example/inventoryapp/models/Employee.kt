package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class Employee(
    @SerializedName("email")
    val email: String,
    @SerializedName("iD_Employee")
    val iDEmployee: Int,
    @SerializedName("middle_Name")
    val middleName: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("surname")
    val surname: String
)