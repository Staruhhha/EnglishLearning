package com.example.inventoryapp.data

import com.example.inventoryapp.models.Users
import io.paperdb.Paper

class UserInfo {

    companion object{
        fun addUserInfo(user : Users){
            Paper.book("user").write("user", user)
        }

        fun getEmployeeInfo() : Users?{
            return Paper.book("user").read("user")
        }
    }

}