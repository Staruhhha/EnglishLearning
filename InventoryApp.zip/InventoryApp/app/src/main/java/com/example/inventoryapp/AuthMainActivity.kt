package com.example.inventoryapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Log.d
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.inventoryapp.data.StudentInfo
import com.example.inventoryapp.databinding.ActivityAuthMainBinding
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import io.paperdb.Paper


class AuthMainActivity : AppCompatActivity() {

    lateinit var binding : ActivityAuthMainBinding
    lateinit var mGoogleSignInClient : GoogleSignInClient
    //val RC_SIGN_IN = 12



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth_main)

        Paper.init(this)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_auth_main)


        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build()

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        binding.googleSignIn.setOnClickListener {
            val signInIntent = mGoogleSignInClient.signInIntent;
            resultLaunch.launch(signInIntent)
        }

        binding.buttonGoLogin.setOnClickListener {
            val intentAuth = Intent(this, AuthActivity::class.java)
            startActivity(intentAuth)
        }

    }

    private var resultLaunch = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){ result ->
        d("message2", "${result.resultCode}")
        if (result.resultCode == 0){
            var task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            //d("message", "${task.result.account}")
            handleSignInResult(task)
        }
    }

    private fun handleSignInResult(task: Task<GoogleSignInAccount>?) {
            var account : GoogleSignInAccount = task!!.getResult(ApiException::class.java)
            if (!account.email.toString().contains("@mpt.ru")){
                mGoogleSignInClient.signOut()
                Toast.makeText(this, "Почта должна принадлежать домену МПТ (@mpt.ru)", Toast.LENGTH_SHORT).show()
                Log.e("msg", "${account.email}")
            }else{
                StudentInfo.addStudInfo(StudentInfo(account.email.toString(), account.givenName.toString(), account.familyName.toString()))
                Toast.makeText(this, "Авторизация", Toast.LENGTH_SHORT).show()
                val intentSend = Intent(this, SendReqActivity::class.java)
                startActivity(intentSend)
                finish()
                Log.e("msg", "${account.email}")
            }
    }

}