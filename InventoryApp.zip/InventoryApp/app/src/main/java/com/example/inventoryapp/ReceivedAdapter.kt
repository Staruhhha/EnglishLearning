package com.example.inventoryapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.inventoryapp.models.RequestTechnic

class ReceivedAdapter(val context: Context, val receivedList : ArrayList<RequestTechnic>,
val listener : (RequestTechnic) -> Unit) : RecyclerView.Adapter<ReceivedAdapter.ViewHolder>() {

    class ViewHolder(view : View) : RecyclerView.ViewHolder(view){
        val textItem = view.findViewById<TextView>(R.id.item_req)
        val textCab = view.findViewById<TextView>(R.id.cab_number)
        val textDate = view.findViewById<TextView>(R.id.req_date)

        fun bindView(item : RequestTechnic, listener: (RequestTechnic) -> Unit){
            itemView.setOnClickListener { listener(item) }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(LayoutInflater.from(context).inflate(R.layout.card_received, parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textItem.text = "${receivedList[position].technicCabinet!!.technic.typeTechnic.nameTypeTechnic} ${receivedList[position].technicCabinet!!.technic.brend.nameBrend} ${receivedList[position].technicCabinet!!.technic.nameTechnic}"
        holder.textCab.text = "${receivedList[position].technicCabinet!!.cabinet.numberCabinet} каб."
        holder.textDate.text = "${receivedList[position].dateTime}"
        holder.bindView(receivedList[position], listener)
    }

    override fun getItemCount(): Int = receivedList.size
}