package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class RequestTechnic(
    @SerializedName("date_Time")
    var dateTime: String = "",
    @SerializedName("employee")
    var employee: Employee? = null,
    @SerializedName("employee_ID")
    var employeeID: Int = 0,
    @SerializedName("iD_Request")
    var iDRequest: Int = 0,
    @SerializedName("problem")
    var problem: String = "",
    @SerializedName("status_Request")
    var statusRequest: StatusRequest? = null,
    @SerializedName("status_Request_ID")
    var statusRequestID: Int = 0,
    @SerializedName("technic_Cabinet")
    var technicCabinet: TechnicCabinet? = null,
    @SerializedName("technic_Cabinet_ID")
    var technicCabinetID: Int = 0
)