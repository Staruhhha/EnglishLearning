package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class TypeCabinet(
    @SerializedName("iD_Type_Cabinet")
    val iDTypeCabinet: Int,
    @SerializedName("name_Type_Cabinet")
    val nameTypeCabinet: String
)