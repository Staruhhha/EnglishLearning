package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class Brend(
    @SerializedName("iD_Brend")
    val iDBrend: Int,
    @SerializedName("name_Brend")
    val nameBrend: String
)