package com.example.inventoryapp.data

import com.example.inventoryapp.models.Users
import io.paperdb.Paper

class StudentInfo(var email : String = "", val givenName : String = "", val familyName : String = "") {

    companion object {
        fun addStudInfo(stud : StudentInfo){
            Paper.book("student").write("student", stud)
        }

        fun getStudInfo() : StudentInfo?{
            return Paper.book("student").read("student")
        }
    }

}