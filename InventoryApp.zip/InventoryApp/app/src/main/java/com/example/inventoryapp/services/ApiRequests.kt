package com.example.inventoryapp.services

import com.example.inventoryapp.models.RequestTechnic
import com.example.inventoryapp.models.StatusRequest
import com.example.inventoryapp.models.Users
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PUT
import retrofit2.http.Path

interface ApiRequests {

    @GET("users/search/{login}")
    fun authUserByLogin(@Path("login") login : String?) : Call<Users>

    @GET("Request_Technic/received/{id_employee}")
    fun getReceivedRequests(@Path("id_employee") id_employee : Int) : Call<ArrayList<RequestTechnic>>

    @GET("Request_Technic/inwork/{id_employee}")
    fun getInWorkRequest(@Path("id_employee") id_employee : Int) : Call<ArrayList<RequestTechnic>>

    @GET("Status_Request/spinner")
    fun getStatusForSpinner() : Call<ArrayList<StatusRequest>>

    @GET("Request_Technic/{id}")
    fun getReceivedRequestById(@Path("id") id:Int) : Call<RequestTechnic>

    @PUT("Request_Technic/{id}")
    fun applyRequest(@Path("id") id : Int, @Body updateReq : RequestTechnic) : Call<RequestTechnic>

}