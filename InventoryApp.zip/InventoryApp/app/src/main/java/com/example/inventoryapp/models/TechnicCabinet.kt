package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class TechnicCabinet(
    @SerializedName("cabinet")
    val cabinet: Cabinet,
    @SerializedName("cabinet_ID")
    val cabinetID: Int,
    @SerializedName("iD_Technic_Cabinet")
    val iDTechnicCabinet: Int,
    @SerializedName("number")
    val number: String,
    @SerializedName("qR_Code")
    val qRCode: Any,
    @SerializedName("technic")
    val technic: Technic,
    @SerializedName("technic_ID")
    val technicID: Int
)