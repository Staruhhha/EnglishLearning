package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class StatusRequest(
    @SerializedName("iD_Status_Request")
    val iDStatusRequest: Int,
    @SerializedName("status")
    val status: String

){
    override fun toString(): String {
        return status
    }
}