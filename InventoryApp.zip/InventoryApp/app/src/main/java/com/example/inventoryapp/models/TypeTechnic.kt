package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class TypeTechnic(
    @SerializedName("iD_Type_Technic")
    val iDTypeTechnic: Int,
    @SerializedName("name_Type_Technic")
    val nameTypeTechnic: String
)