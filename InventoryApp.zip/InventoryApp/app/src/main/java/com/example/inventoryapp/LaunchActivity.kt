package com.example.inventoryapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.example.inventoryapp.data.StudentInfo
import com.example.inventoryapp.data.UserInfo
import com.example.inventoryapp.models.Users
import io.paperdb.Paper

class LaunchActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launch)

        Paper.init(this)

        Handler(Looper.getMainLooper()).postDelayed({
            val userInfo : Users? = UserInfo.getEmployeeInfo()
            val studInfo : StudentInfo? = StudentInfo.getStudInfo()
            if (userInfo == null && studInfo == null){
                val intent = Intent(this, AuthMainActivity::class.java)
                startActivity(intent)
                finish()
            }else{
                if (userInfo != null){
                    val intentMain = Intent(this, MainActivity::class.java)
                    startActivity(intentMain)
                    finish()
                }else if (studInfo != null){
                    val intentSend = Intent(this, SendReqActivity::class.java)
                    startActivity(intentSend)
                    finish()
                }
            }
        },3000)

    }
}