package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class Cabinet(
    @SerializedName("iD_Cabinet")
    val iDCabinet: Int,
    @SerializedName("number_Cabinet")
    val numberCabinet: String,
    @SerializedName("type_Cabinet")
    val typeCabinet: TypeCabinet,
    @SerializedName("type_Cabinet_ID")
    val typeCabinetID: Int
)