package com.example.inventoryapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.withStyledAttributes
import androidx.databinding.DataBindingUtil
import com.example.inventoryapp.databinding.ActivityDetailReceiveBinding
import com.example.inventoryapp.models.RequestTechnic
import com.example.inventoryapp.services.ApiRequests
import com.example.inventoryapp.services.ServiceBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailReceiveActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailReceiveBinding
    private var requestTechnic : RequestTechnic = RequestTechnic()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_receive)

        binding = DataBindingUtil.setContentView(this , R.layout.activity_detail_receive)
        val id = intent.getIntExtra("idReq",0)
        supportActionBar?.title = "Заявка №$id"
        val serviceBuilder = ServiceBuilder.buildServices(ApiRequests::class.java)
        val reqCall = serviceBuilder.getReceivedRequestById(id)
        reqCall.enqueue(object : Callback<RequestTechnic>{
            override fun onResponse(
                call: Call<RequestTechnic>,
                response: Response<RequestTechnic>
            ) {
                if (response.isSuccessful){
                    requestTechnic = response.body()!!
                    setView(requestTechnic)
                }else{
                    Toast.makeText(this@DetailReceiveActivity, "Произошла ошибка", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<RequestTechnic>, t: Throwable) {
                Toast.makeText(this@DetailReceiveActivity, "${t.message}", Toast.LENGTH_SHORT).show()
            }

        })

        binding.buttonApply.setOnClickListener {
            applyReq(requestTechnic)
        }

    }

    private fun setView(req : RequestTechnic){
        binding.recTitle.text = "${req.technicCabinet!!.technic.typeTechnic.nameTypeTechnic} ${req.technicCabinet!!.technic.brend.nameBrend} ${req.technicCabinet!!.technic.nameTechnic}"
        binding.recCab.text = "${req.technicCabinet!!.cabinet.numberCabinet}"
        binding.recDate.text = "${req.dateTime}"
        binding.recComment.text = "${req.problem}"
    }

    private fun applyReq(request:RequestTechnic){
        request.statusRequestID = 2
        val serviceBuilder = ServiceBuilder.buildServices(ApiRequests::class.java)
        val reqCall = serviceBuilder.applyRequest(request.iDRequest, request)
        reqCall.enqueue(object : Callback<RequestTechnic>{
            override fun onResponse(
                call: Call<RequestTechnic>,
                response: Response<RequestTechnic>
            ) {
                if (response.isSuccessful){
                    Toast.makeText(this@DetailReceiveActivity, "Заявка принята", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@DetailReceiveActivity, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }

            override fun onFailure(call: Call<RequestTechnic>, t: Throwable) {
                Toast.makeText(this@DetailReceiveActivity, "${t.message}", Toast.LENGTH_SHORT).show()
            }

        })
    }

}