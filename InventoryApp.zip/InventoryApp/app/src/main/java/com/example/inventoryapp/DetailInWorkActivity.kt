package com.example.inventoryapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.inventoryapp.databinding.ActivityDetailInWorkBinding
import com.example.inventoryapp.databinding.ActivityDetailReceiveBinding
import com.example.inventoryapp.models.RequestTechnic
import com.example.inventoryapp.models.StatusRequest
import com.example.inventoryapp.services.ApiRequests
import com.example.inventoryapp.services.ServiceBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailInWorkActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailInWorkBinding
    private var requestTechnic : RequestTechnic = RequestTechnic()
    private var statusIdFromSpinner = 0



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_in_work)

        binding = DataBindingUtil.setContentView(this , R.layout.activity_detail_in_work)
        val id = intent.getIntExtra("idReq",0)
        supportActionBar?.title = "Заявка №$id"
        val serviceBuilder = ServiceBuilder.buildServices(ApiRequests::class.java)
        val reqCall = serviceBuilder.getReceivedRequestById(id)
        reqCall.enqueue(object : Callback<RequestTechnic> {
            override fun onResponse(
                call: Call<RequestTechnic>,
                response: Response<RequestTechnic>
            ) {
                if (response.isSuccessful){
                    requestTechnic = response.body()!!
                    setView(requestTechnic)
                }else{
                    Toast.makeText(this@DetailInWorkActivity, "Произошла ошибка", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<RequestTechnic>, t: Throwable) {
                Toast.makeText(this@DetailInWorkActivity, "${t.message}", Toast.LENGTH_SHORT).show()
            }

        })
        binding.statusSpinner.onItemSelectedListener = object : OnItemSelectedListener{
            override fun onItemSelected(adapterView: AdapterView<*>?, view: View?, i: Int, l: Long) {
                var spn = adapterView!!.getItemAtPosition(i) as StatusRequest
                statusIdFromSpinner = spn.iDStatusRequest
                //Toast.makeText(this@DetailInWorkActivity, "$statusIdFromSpinner", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(adapterView: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

        }

        binding.buttonApply.setOnClickListener {
            applyChange(requestTechnic)
        }

    }

    private fun applyChange(request: RequestTechnic) {
        request.statusRequestID = statusIdFromSpinner
        val serviceBuilder = ServiceBuilder.buildServices(ApiRequests::class.java)
        val reqCall = serviceBuilder.applyRequest(request.iDRequest, request)
        reqCall.enqueue(object : Callback<RequestTechnic>{
            override fun onResponse(
                call: Call<RequestTechnic>,
                response: Response<RequestTechnic>
            ) {
                if (response.isSuccessful){
                    Toast.makeText(this@DetailInWorkActivity, "Статус заявки изменен", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@DetailInWorkActivity, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }

            override fun onFailure(call: Call<RequestTechnic>, t: Throwable) {
                Toast.makeText(this@DetailInWorkActivity, "${t.message}", Toast.LENGTH_SHORT).show()
            }

        })
    }

    private fun setView(req: RequestTechnic) {
        binding.recTitle.text = "${req.technicCabinet!!.technic.typeTechnic.nameTypeTechnic} ${req.technicCabinet!!.technic.brend.nameBrend} ${req.technicCabinet!!.technic.nameTechnic}"
        binding.recCab.text = "${req.technicCabinet!!.cabinet.numberCabinet}"
        binding.recDate.text = "${req.dateTime}"
        binding.recComment.text = "${req.problem}"
        setSpinnerReq(req.statusRequestID)
    }

    private fun setSpinnerReq(id : Int) {
        val serviceBuilder = ServiceBuilder.buildServices(ApiRequests::class.java)
        val requestCall = serviceBuilder.getStatusForSpinner()
        requestCall.enqueue(object : Callback<ArrayList<StatusRequest>>{
            override fun onResponse(
                call: Call<ArrayList<StatusRequest>>,
                response: Response<ArrayList<StatusRequest>>
            ) {
                if (response.isSuccessful){
                    val spinnerAdapter = ArrayAdapter(this@DetailInWorkActivity, android.R.layout.simple_spinner_dropdown_item, response.body()!!)
                    binding.statusSpinner.adapter = spinnerAdapter
                    binding.statusSpinner.setSelection(1)
                }
            }

            override fun onFailure(call: Call<ArrayList<StatusRequest>>, t: Throwable) {
                Toast.makeText(this@DetailInWorkActivity, "${t.message}", Toast.LENGTH_SHORT).show()
            }

        })
    }
}