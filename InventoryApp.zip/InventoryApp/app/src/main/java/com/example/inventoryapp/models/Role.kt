package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class Role(
    @SerializedName("iD_Role")
    val iDRole: Int,
    @SerializedName("name_Role")
    val nameRole: String
)