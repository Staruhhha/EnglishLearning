package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class Technic(
    @SerializedName("brend")
    val brend: Brend,
    @SerializedName("brend_ID")
    val brendID: Int,
    @SerializedName("iD_Technic")
    val iDTechnic: Int,
    @SerializedName("name_Technic")
    val nameTechnic: String,
    @SerializedName("type_Technic")
    val typeTechnic: TypeTechnic,
    @SerializedName("type_Technic_ID")
    val typeTechnicID: Int
)