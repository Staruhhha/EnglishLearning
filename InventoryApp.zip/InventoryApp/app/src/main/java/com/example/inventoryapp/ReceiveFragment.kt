package com.example.inventoryapp

import android.app.Application
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.inventoryapp.data.UserInfo
import com.example.inventoryapp.models.RequestTechnic
import com.example.inventoryapp.services.ApiRequests
import com.example.inventoryapp.services.ServiceBuilder
import io.paperdb.Paper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ReceiveFragment : Fragment() {

    private lateinit var receivedRecycler : RecyclerView
    private lateinit var progress : ProgressBar

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var item = UserInfo.getEmployeeInfo()
        progress.visibility = View.VISIBLE
        getData(item!!.employeeID)
    }

    fun getData(id : Int){
        val serviceBuilder = ServiceBuilder.buildServices(ApiRequests::class.java)
        val requestCall = serviceBuilder.getReceivedRequests(id)
        requestCall.enqueue(object : Callback<ArrayList<RequestTechnic>>{
            override fun onResponse(
                call: Call<ArrayList<RequestTechnic>>,
                response: Response<ArrayList<RequestTechnic>>
            ) {
                receivedRecycler.layoutManager = LinearLayoutManager(context)
                receivedRecycler.setHasFixedSize(true)
                receivedRecycler.adapter = ReceivedAdapter(context!!, response.body()!!){
                    val intent = Intent(context, DetailReceiveActivity::class.java)
                    intent.putExtra("idReq", it.iDRequest)
                    startActivity(intent)
                }
                progress.visibility = View.GONE
            }

            override fun onFailure(call: Call<ArrayList<RequestTechnic>>, t: Throwable) {
                Toast.makeText(context, "${t.message}", Toast.LENGTH_SHORT).show()
            }

        })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Paper.init(requireContext())
        val receive = inflater.inflate(R.layout.fragment_receive, container, false)
        receivedRecycler = receive.findViewById(R.id.receive_list)
        progress = receive.findViewById(R.id.progress_rec)
        return receive
    }
}