package com.example.inventoryapp.models


import com.google.gson.annotations.SerializedName

data class Users(
    @SerializedName("employee")
    val employee: Employee,
    @SerializedName("employee_ID")
    val employeeID: Int,
    @SerializedName("iD_User")
    val iDUser: Int,
    @SerializedName("login")
    val login: String,
    @SerializedName("password")
    val password: String,
    @SerializedName("role")
    val role: Role,
    @SerializedName("role_ID")
    val roleID: Int
)